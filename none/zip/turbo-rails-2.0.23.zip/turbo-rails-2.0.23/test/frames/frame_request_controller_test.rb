require "test_helper"

class Turbo::FrameRequestControllerTest < ActionDispatch::IntegrationTest
  test "frame requests are rendered with a minimal layout" do
    get tray_path(id: 1)
    assert_select "title", count: 1

    get tray_path(id: 1), headers: { "Turbo-Frame" => "true" }
    assert_select "title", count: 0
  end

  test "frame request layout includes `head` content" do
    get tray_path(id: 1), headers: { "Turbo-Frame" => "true" }

    assert_select "head", count: 1
    assert_select "meta[name=test][content=present]"
    assert_select "meta[name=csrf-param]"
    assert_select "meta[name=csrf-token]"
  end

  test "frame request layout can be overridden" do
    with_prepended_view_path "test/frames/views" do
      get tray_path(id: 1), headers: { "Turbo-Frame" => "true" }
    end

    assert_select "meta[name=test][content=present]"
    assert_select "meta[name=alternative][content=present]"
  end

  test "frame requests get a unique etag" do
    get tray_path(id: 1)
    etag_without_frame = @response.headers["ETag"]

    get tray_path(id: 1), headers: { "Turbo-Frame" => "true" }
    etag_with_frame = @response.headers["ETag"]

    assert_not_equal etag_with_frame, etag_without_frame
  end

  test "turbo_frame_request_id returns the Turbo-Frame header value" do
    turbo_frame_request_id = "test_frame_id"

    get tray_path(id: 1)
    assert_no_match(/#{turbo_frame_request_id}/, @response.body)

    get tray_path(id: 1), headers: { "Turbo-Frame" => turbo_frame_request_id }
    assert_match(/#{turbo_frame_request_id}/, @response.body)
  end

  private
    def with_prepended_view_path(path, &block)
      previous_view_paths = ApplicationController.view_paths
      ApplicationController.prepend_view_path path
      yield
    ensure
      ApplicationController.view_paths = previous_view_paths
    end
end

class Turbo::FrameRequestViewTest < ActionView::TestCase
  test "supports rendering context without request object" do
    @rendered = ApplicationController.render(template: "trays/show")

    assert_dom "html" do |html|
      assert_dom html, "head" do |head|
        assert_dom head, "title", text: "Dummy"
        assert_dom head, "script"
      end
      assert_dom html, "body:not(.turbo-native)" do |body|
        assert_dom body, "turbo-frame#tray"
      end
    end
  end

  class Turbo::TestAssertions::FrameTest < ActionDispatch::IntegrationTest
    test "assert_turbo_frame passes with matching frame" do
      get tray_path(id: 1)
      assert_turbo_frame "tray"
    end

    test "assert_turbo_frame fails without matching frame" do
      get tray_path(id: 1)
      assert_raises Minitest::Assertion do
        assert_turbo_frame "missing"
      end
    end

    test "assert_no_turbo_frame fails with matching frame" do
      get tray_path(id: 1)
      assert_raises Minitest::Assertion do
        assert_no_turbo_frame "tray"
      end
    end

    test "assert_no_turbo_frame fails without matching frame" do
      get tray_path(id: 1)
      assert_no_turbo_frame "missing"
    end
  end
end
